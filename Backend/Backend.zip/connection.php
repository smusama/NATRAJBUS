<?php

/* localhost connection */
/* 
$mysql_hostname="localhost";
$mysql_user="root";
$mysql_password="";
$mysql_database="n_bus_online";
$bd = mysql_connect($mysql_hostname, $mysql_user, $mysql_password) or die("Could not connect database");
mysql_select_db($mysql_database, $bd) or die("Could not select database");*/

/* server connection*/
$mysql_hostname="localhost";
$mysql_user="natrajbu_online";
$mysql_password="xbZXEk{_DRJg";
$mysql_database="natrajbu_online";
$bd = mysql_connect($mysql_hostname, $mysql_user, $mysql_password) or die("Could not connect database");
mysql_select_db($mysql_database, $bd) or die("Could not select database"); 
error_reporting(0);


function login_check() {
	if(!@$_SESSION['username']){ 
	if(!$_SESSION['role']){
		echo "<script>window.location='loginu.php'</script>";
		end;
	}
	}
	}
?>